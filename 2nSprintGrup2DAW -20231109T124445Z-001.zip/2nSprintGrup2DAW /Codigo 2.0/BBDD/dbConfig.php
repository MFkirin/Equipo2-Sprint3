<?php
$dbConfig = [
    'host' => 'mysql-server',
    'dbname' => 'db_proyecto',
    'username' => 'root',
    'password' => 'secret',
];