document.addEventListener("DOMContentLoaded", function () {
  let clickColor = document.getElementById("clickColor");
  let Negre = document.getElementById("Negre");
  let Taronja = document.getElementById("Taronja");
  let Blau = document.getElementById("Blau");
  let divColor = document.getElementById("divColor");
  let dobleClick = document.getElementById("dobleClick");
  let divDobleClick = document.getElementById("divDobleClick");
  let anyNaixement = document.getElementById("anyNaixement");

  let colorDivColor = "black";

  anyNaixement.addEventListener ("blur", function() {
    if (parseInt(anyNaixement.value) < "1920") {
      anyNaixement.value = "1920";
    }
    if (parseInt(anyNaixement.value) > "2005") {
      anyNaixement.value = "2005";
    }
  });



  Negre.addEventListener("click", function (event) {
    colorDivColor = "black";
    divColor.style.backgroundColor = colorDivColor;
  });

  Taronja.addEventListener("click", function (event) {
    colorDivColor = "orange";
    divColor.style.backgroundColor = colorDivColor;
  });

  Blau.addEventListener("click", function (event) {
    colorDivColor = "blue";
    divColor.style.backgroundColor = colorDivColor;
  });

  //Click i dobleclick
  dobleClick.ondblclick = function () {
    let nouP = document.createElement("p");
    nouP.id = "pSoluciona";
    nouP.textContent = "Fes-me click per revertir els canvis";

    dobleClick.style.backgroundColor = "black";
    divDobleClick.appendChild(nouP);

    nouP.addEventListener("click", function () {
      nouP.remove();

      let dobleClick = document.getElementById("dobleClick");

      dobleClick.style.backgroundColor = "white";

    });
  };

});
