Este repositorio contiene una recopilación de actividades muy sencillas
realizadas en la primera clase sobre Sistemas de control de versiones.
1. Configuración de algunas preferencias
2. Instrucciones para la creación de un primer repositorio
3. Añadir un archivo al repositorio moviéndolo de la stage area a la zona local comprobando el estado.
1234
