const http = require('http');

const server = http.createServer((req, res) => {
  res.statusCode = 200; // Código de estado 200 indica una respuesta exitosa
  res.setHeader('Content-Type', 'text/plain'); // Tipo de contenido: texto plano
  res.end('Hola, mundo!\n'); // Mensaje de respuesta
});

server.listen(3000, '0.0.0.0', () => {
  console.log('El servidor está escuchando en el puerto 3000');
});
