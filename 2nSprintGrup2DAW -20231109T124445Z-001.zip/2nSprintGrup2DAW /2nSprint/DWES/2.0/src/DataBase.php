<?php

require 'src/Exceptions/DatabaseException.php';

class DataBase
{
    private PDO $dbConnection;

    public function __construct(array $config)
    {
        try {
            $host = $config['host'];
            $dbName = $config['dbname'];
            $username = $config['username'];
            $password = $config['password'];

            $this->dbConnection = new PDO("mysql:host=$host;dbname=$dbName", $username, $password);
            $this->dbConnection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $e) {
            die($e->getMessage());
        }
    }

    public function getProviders()
    {
        try {
            $consulta = $this->dbConnection->query("SELECT * FROM proveedor");
            return $consulta->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            die($e->getMessage());
        }
    }

    public function getVehicles()
    {
        try {
            $consulta = $this->dbConnection->query("SELECT * FROM vehiculo");
            return $consulta->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            die($e->getMessage());
        }
    }


    public function insertProvider(Provider $provider)
    {
        try {
            $consulta = $this->dbConnection->prepare("INSERT INTO proveedor (DNI, documento_LOPD, NIF_Gerente, documento_constitucion, CIF, certificado_cuenta_bancaria, domicilio_completo, telefono, nombre, correo_electronico) 
VALUES (:DNI, :documento_LOPD, :NIF_Gerente, :documento_constitucion, :CIF, :certificado_cuenta_bancaria, :domicilio_completo, :telefono, :nombre, :correo_electronico)");

            $values = [
                ':DNI' => $provider->getDni(),
                ':documento_LOPD' => '',
                ':NIF_Gerente' => $provider->getManagerNIF(),
                ':documento_constitucion' => '',
                ':CIF' => $provider->getCIF(),
                ':certificado_cuenta_bancaria' => '',
                ':domicilio_completo' => $provider->getCompleteAddress(),
                ':telefono' => $provider->getPhone(),
                ':nombre' => $provider->getName(),
                ':correo_electronico' => $provider->getEmail(),
            ];

            $success = $consulta->execute($values);

            if ($success) {
                return true;
            } else {
                throw new DatabaseException("Error al insertar datos en la base de datos");
            }
        } catch (DatabaseException|PDOException $e) {
            die($e->getMessage());
        }
    }

    public function insertVehicle(Vehicle $vehicle)
    {
        try {
            $consulta = $this->dbConnection->prepare("INSERT INTO vehiculo (matricula, color, danos, id_modelo, tipo_carburante, fecha_matriculacion, 
            kilometros, id_marca, descripcion, iva, num_bastidor, tipo_cambio, precio_venta, precio_compra, id_comanda) 
            VALUES (:matricula, :color, :danos, :id_modelo, :tipo_carburante, STR_TO_DATE(:fecha_matriculacion, '%Y-%m-%d'), 
            :kilometros, :id_marca, :descripcion, :iva, :num_bastidor, :tipo_cambio, :precio_venta, :precio_compra, :id_comanda)");

            $values = [
                ':matricula' => $vehicle->getPlate(),
                ':color' => $vehicle->getColor(),
                ':danos' => $vehicle->getObservedDamages(),
                ':id_modelo' => null,
                ':tipo_carburante' => $vehicle->getFuel(),
                ':fecha_matriculacion' => $vehicle->getRegistrationDate()->format('Y-m-d'),
                ':kilometros' => $vehicle->getKm(),
                ':id_marca' => null,
                ':descripcion' => $vehicle->getDescription(),
                ':iva' => $vehicle->getIva(),
                ':num_bastidor' => $vehicle->getNumChassis(),
                ':tipo_cambio' => $vehicle->getGearShift(),
                ':precio_venta' => $vehicle->getSellPrice(),
                ':precio_compra' => $vehicle->getBuyPrice(),
                ':id_comanda' => null,
            ];

            $success = $consulta->execute($values);

            if ($success) {
                return true;
            } else {
                throw new DatabaseException("Error al insertar datos del vehículo en la base de datos");
            }
        } catch (DatabaseException|PDOException $e) {
            die($e->getMessage());
        }
    }

    public function deleteProvider($providerId)
    {
        try {
            $consulta = $this->dbConnection->prepare("DELETE FROM proveedor WHERE ID = :id");
            $consulta->execute([':id' => $providerId]);
            return true;
        } catch (PDOException $e) {
            die($e->getMessage());
        }
    }

    public function deleteVehicle($vehicleId)
    {
        try {
            $consulta = $this->dbConnection->prepare("DELETE FROM vehiculo WHERE id = :id");
            $consulta->execute([':id' => $vehicleId]);
            return true;
        } catch (PDOException $e) {
            die($e->getMessage());
        }
    }

}