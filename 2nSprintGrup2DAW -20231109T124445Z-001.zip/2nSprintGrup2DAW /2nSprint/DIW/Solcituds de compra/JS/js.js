document.addEventListener("DOMContentLoaded", function () {

const botonHamburguesa = document.getElementById('hamburguesa');
const aside = document.querySelector('aside');

botonHamburguesa.addEventListener('click', toggleAside);

function toggleAside() {
    aside.classList.toggle('visible');
}
});
