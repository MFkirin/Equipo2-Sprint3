document.addEventListener("DOMContentLoaded", function(){

    let creu = document.getElementById("creuCookies");
    let politica = document.getElementById("politica");

    creu.addEventListener("click", function() {
        politica.style.display = "none";
    });


});
