document.addEventListener("DOMContentLoaded", function () {
  const pixels_a_moure = 15;
  let avio = document.getElementById("avio");
  const musica = document.getElementById("musica");
  const audioEsMou = document.getElementById("audioEsMou");
  let menu = document.getElementById("menu");
  /*getElementByClassName torna una colecció de nodes, al tindre sols un div amb la classe marcador, no funcionava
  per aixó empre querySelector  */
  let imgAvio = document.getElementById("imgAvio");
  let marcador = document.querySelector(".marcador");
  let textMarcador = document.createTextNode("100 pt")
  marcador.appendChild(textMarcador);
  musica.play();
  


  function moureEsquerra() {
    let avioPos = getAvioPos(avio);
    let nuevaPosicion = avioPos.left - pixels_a_moure;
    audioEsMou.play();
    imgAvio.src = "avionGirado.png";
    //No mostre el "propulsor" perque al menejar-se cap a rere no ixiría foc"
    if (nuevaPosicion >= 0) {
      avio.style.left = nuevaPosicion + "px";
    }
    console.log("Volem moure l'avió a l'esquerra");
  }

  function moureDreta() {
    let avioPos = getAvioPos(avio);
    let nuevaPosicion = avioPos.left + pixels_a_moure;
    audioEsMou.play();
    imgAvio.src = "avionMovimiento.png";
    if (nuevaPosicion + avio.offsetWidth <= window.innerWidth) {
      avio.style.left = nuevaPosicion + "px";
    }
    console.log("Volem moure l'avió a la dreta");
  }

  function moureAmunt() {
    let avioPos = getAvioPos(avio);
    let nuevaPosicion = avioPos.top - pixels_a_moure;
    audioEsMou.play();
    imgAvio.src = "avionMovimiento.png";
    if (nuevaPosicion >= 10) {
      avio.style.top = nuevaPosicion + "px";
    }
    console.log("Volem moure l'avió a amunt");
  }

  function moureAvall() {
    let avioPos = getAvioPos(avio);
    let nuevaPosicion = avioPos.top + pixels_a_moure;
    audioEsMou.play();
    imgAvio.src = "avionMovimiento.png";
    if (nuevaPosicion + avio.offsetHeight <= window.innerHeight) {
      avio.style.top = nuevaPosicion + "px";
    }
    console.log("Volem moure l'avió a avall");
  }

  function passarANumero(n) {
    return parseInt(n == "auto" ? 0 : n);
  }

  function getAvioPos(element) {
    let obj = {
      left: passarANumero(getComputedStyle(element).left),
      top: passarANumero(getComputedStyle(element).top),
    };
    return obj;
  }

  function moureAvio(evt) {
    switch (evt.keyCode) {
      case 37:
        moureEsquerra();
        break;
      case 39:
        moureDreta();
        break;
      case 38:
        moureAmunt();
        break;
      case 40:
        moureAvall();
        break;
      case 49:
        if (musica && musica.paused) {
          musica.play();
        } else if (musica) {
          musica.pause();
        }
        break;
    }
  }

  function pararAvio() {
    imgAvio.src = "avion.png";
  }

  window.addEventListener("keydown", moureAvio);
  window.addEventListener("keyup", pararAvio);

  let boton1 = document.getElementById("boton1");
  let boton2 = document.getElementById("boton2");
  let boton3 = document.getElementById("boton3");
  
  boton1.addEventListener('click', mostraFinestraModal);
  boton2.addEventListener('click',canviaFons1);
  boton3.addEventListener('click', canviaFons2);
  

  function canviaFons1() {
    document.body.style.backgroundImage = "url('/fons_nivells/nivell1.jpg')";
  }

  function canviaFons2() {
    document.body.style.backgroundImage = "url('/fons_nivells/nivell2.jpg')";
  }

  function mostraFinestraModal() {
    var modal = document.getElementById("modal");
    modal.style.display = "flex";

    // Configura el evento para cerrar la ventana modal
    var closeBtn = modal.querySelector(".close");
    closeBtn.addEventListener("click", function() {
        modal.style.display = "none";
    });
}

// Asocia la función con el evento clic del botón "Ajuda"
var botonAjuda = document.getElementById("boton1");
botonAjuda.addEventListener("click", mostraFinestraModal);


});
