<?php
//Si rebem la informació del formulari, guardem la informació del s seus camps
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $nombre = $_POST["nombre"];
    $domicilio = $_POST["domicilio"];
    $DNI = $_POST["DNI"];
    $tel = $_POST["tel"];
    $email = $_POST["email"];
    $CIF = $_POST["CIF"];
    $NIFGerente = $_POST["NIF_gerente"];
    //Guardem els missatges d'error retornats per les funcions de validacions
    $errorNombre = validarNombre($nombre);
    $errorDomicilio = validarDomicilio($domicilio);
    $errorDNI = validarDNI($DNI);
    $errorTel = validarTelefono($tel);
    $errorEmail = validarEmail($email);
    $errorCIF = validarCIF($CIF);
    $errorNIFGerente = validarNIFGerente($NIFGerente);

    //Si no hi han errors
    if (
        empty($errorNombre) &&
        empty($errorDomicilio) &&
        empty($errorDNI) &&
        empty($errorTel) &&
        empty($errorEmail) &&
        empty($errorCIF) &&
        empty($errorNIFGerente)
    ) {
       
        echo "Formulario enviado correctamente";
        $datos = "Nombre: $nombre\nDomicilio: $domicilio\nDNI: $DNI\nTeléfono: $tel\nEmail: $email\nCIF: $CIF\nNIF Gerente: $NIFGerente\n";
        //Obri l'archiu (el crea si no existeix). La "w" es per a que origa l'arxiu en mode escritura (write)
        $archivo = fopen("datos_proveedor.txt", "w");
        fwrite($archivo, $datos);
        fclose($archivo);
    } else {
        
        echo "Por favor, complete todos los campos correctamente:<br>";
        echo $errorNombre . "<br>";
        echo $errorDomicilio . "<br>";
        echo $errorDNI . "<br>";
        echo $errorTel . "<br>";
        echo $errorEmail . "<br>";
        echo $errorCIF . "<br>";
        echo $errorNIFGerente . "<br>";
    }
}

function validarNombre($nombre) {
    $error = "";
    if (empty($nombre)) {
        $error = "Error: El campo de nombre campo es necesario";
    } else if (!preg_match("/^[A-Za-z\s]+$/", $nombre)) {
        $error = "Error: El nombre no puede contener números ni caracteres especiales";
    }
    return $error;
}

function validarDomicilio($domicilio) {
   $error = "";
    if (empty($domicilio)) {
        $error = "Error: El campo de domicilio es necesario";
    }
    return $error;
}

function validarDNI($DNI) {
    $error = "";
    $DNIPattern = '/^[0-9]{8}[A-Z]{1}$/';
    if (empty($DNI)) {
        $error = "Error: El campo de DNI es necesario";
    } else if (!preg_match($DNIPattern, $DNI)) {
        $error = "Error: DNI no válido. El formato es: 12345678A";
    }
    return $error;
}

function validarTelefono($tel) {
    $error = "";
    if (empty($tel)) {
        $error = "Error: El campo de teléfono es necesario";
    } else if (!preg_match("/^\d{9}$/", $tel)) {
        $error = "Error: El teléfono debe tener 9 dígitos. El formato es: 555555555";
    }
    return $error;
}

function validarEmail($email) {
    $error = "";
    $emailPattern = '/^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/';
    if (empty($email)) {
        $error = "Error: Este campo es necesario";
    } else if (!preg_match($emailPattern, $email)) {
        $error = "Error: Email no válido. El formato es: example@gmail.com";
    }
    return $error;
}

function validarCIF($CIF) {
    $error = "";
    $CIFPattern = '/^[A-Z]{1}[0-9]{7}[A-Z]{1}$/';
    if (empty($CIF)) {
        $error = "Error: Este campo es necesario";
    } else if (!preg_match($CIFPattern, $CIF)) {
        $error = "Error: CIF no válido";
    }
    return $error;
}

function validarNIFGerente($NIFGerente) {
    $error = "";
    $NIFPattern = '/^[0-9]{8}[A-Z]{1}$/';
    if (empty($NIFGerente)) {
        $error = "Error: Este campo es necesario";
    } else if (!preg_match($NIFPattern, $NIFGerente)) {
        $error = "Error: NIF del gerente no válido";
    }
    return $error;
}
?>
