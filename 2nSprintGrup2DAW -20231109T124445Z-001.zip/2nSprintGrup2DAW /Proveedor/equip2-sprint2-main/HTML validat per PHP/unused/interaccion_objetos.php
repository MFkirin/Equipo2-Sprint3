<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Interacción de Vehículos</title>
</head>

<body>
    <h1>Lista de Vehículos</h1>

    <?php
    session_start();

    // Inicializar la lista de vehículos si no está definida en la sesión
    if (!isset($_SESSION['vehiculos'])) {
        $_SESSION['vehiculos'] = [];
    }

    // Manejar la creación de un nuevo vehículo
    if (isset($_POST['nuevo'])) {
        $nuevoVehiculo = [
            "matricula" => "ABC" . rand(100, 999),
            "color" => ["Rojo", "Azul", "Verde", "Blanco"][array_rand(["Rojo", "Azul", "Verde", "Blanco"])],
            "modelo" => ["Sedán", "SUV", "Camioneta", "Deportivo"][array_rand(["Sedán", "SUV", "Camioneta", "Deportivo"])],
            "precio_venta" => rand(10000, 50000),
            "precio_compra" => rand(8000, 45000)
        ];

        // Agregar el nuevo vehículo a la lista
        $_SESSION['vehiculos'][] = $nuevoVehiculo;
    }
    ?>

    <table>
        <tr>
            <th>Matrícula</th>
            <th>Color</th>
            <th>Modelo</th>
            <th>Precio Venta</th>
            <th>Precio Compra</th>
        </tr>
        <?php
        // Mostrar los vehículos en la lista
        foreach ($_SESSION['vehiculos'] as $vehiculo) {
            echo "<tr>";
            echo "<td>" . $vehiculo["matricula"] . "</td>";
            echo "<td>" . $vehiculo["color"] . "</td>";
            echo "<td>" . $vehiculo["modelo"] . "</td>";
            echo "<td>" . $vehiculo["precio_venta"] . "</td>";
            echo "<td>" . $vehiculo["precio_compra"] . "</td>";
            echo "</tr>";
        }
        ?>
    </table>

    <form method="post">
        <input type="submit" name="nuevo" value="Nuevo">
    </form>
</body>

</html>
