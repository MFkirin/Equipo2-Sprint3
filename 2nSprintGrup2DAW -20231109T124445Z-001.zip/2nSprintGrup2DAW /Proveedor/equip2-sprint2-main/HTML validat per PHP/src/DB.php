<?php
class Database extends exception{
    private $dbConnection;

    public function __construct($host, $dbName, $username, $password) {
        try {
            $this->dbConnection = new PDO("mysql:host=$host;dbname=$dbName", $username, $password);
            $this->dbConnection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $exception) {
            throw new Exception("Error de conexión a la base de datos: " . $exception->getMessage());
        }
    }

    public function insertProveedor($nombre, $domicilio, $DNI, $tel, $email, $CIF, $NIFGerente) {
        try {
            $consulta = $this->dbConnection->prepare("INSERT INTO proveedores (nombre, domicilio, DNI, telefono, email, CIF, NIF_gerente) VALUES (?, ?, ?, ?, ?, ?, ?)");
            $consulta->execute([$nombre, $domicilio, $DNI, $tel, $email, $CIF, $NIFGerente]);
            return true;
        } catch (PDOException $exception) {
            throw new Exception("Error al insertar los datos del proveedor: " . $exception->getMessage());
        }
    }
}
?>

