<?php 
class Proveedor {
    private $Nombre;
    private $domicilio;
    private $DNI;
    private $telefono;
    private $email;
    private $CIF;
    private $NIFGerente;

    public function __construct($nombre, $domicilio, $DNI, $telefono, $email, $CIF, $NIFGerente) {
        $this->Nombre = $nombre;
        $this->domicilio = $domicilio;
        $this->DNI = $DNI;
        $this->telefono = $telefono;
        $this->email = $email;
        $this->CIF = $CIF;
        $this->NIFGerente = $NIFGerente;
    }

    public function getNombre() {
        return $this->Nombre;
    }

    public function setNombre($nombre) {
        $this->Nombre = $nombre;
    }

    public function getDomicilio() {
        return $this->domicilio;
    }

    public function setDomicilio($domicilio) {
        $this->domicilio = $domicilio;
    }

    public function getDNI() {
        return $this->DNI;
    }

    public function setDNI($DNI) {
        $this->DNI = $DNI;
    }

    public function getTelefono() {
        return $this->telefono;
    }

    public function setTelefono($telefono) {
        $this->telefono = $telefono;
    }

    public function getEmail() {
        return $this->email;
    }

    public function setEmail($email) {
        $this->email = $email;
    }

    public function getCIF() {
        return $this->CIF;
    }

    public function setCIF($CIF) {
        $this->CIF = $CIF;
    }

    public function getNIFGerente() {
        return $this->NIFGerente;
    }

    public function setNIFGerente($NIFGerente) {
        $this->NIFGerente = $NIFGerente;
    }
}

?>