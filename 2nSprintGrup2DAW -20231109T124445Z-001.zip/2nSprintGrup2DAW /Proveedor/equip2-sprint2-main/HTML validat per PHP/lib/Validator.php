<?php
class Validator {
    public static function validarCampos($campos) {
        $errores = [];
        foreach ($campos as $campo => $valor) {
            switch ($campo) {
                case 'nombre':
                    $errores[$campo] = self::validarNombre($valor);
                    break;
                case 'domicilio':
                    $errores[$campo] = self::validarDomicilio($valor);
                    break;
                case 'DNI':
                    $errores[$campo] = self::validarDNI($valor);
                    break;
                case 'tel':
                    $errores[$campo] = self::validarTelefono($valor);
                    break;
                case 'email':
                    $errores[$campo] = self::validarEmail($valor);
                    break;
                case 'CIF':
                    $errores[$campo] = self::validarCIF($valor);
                    break;
                case 'NIF_gerente':
                    $errores[$campo] = self::validarNIFGerente($valor);
                    break;
                default:
                    // Campo desconocido, manejar según sea necesario
                    break;
            }
        }
        return $errores;
    }

    private static function validarNombre($nombre) {
        $error = "";
        if (empty($nombre)) {
            $error = "El campo de nombre es necesario";
        } else if (!preg_match("/^[A-Za-z\s]+$/", $nombre)) {
            $error = "El nombre no puede contener números ni caracteres especiales";
        }
        return $error;
    }

    private static function validarDomicilio($domicilio) {
        $error = "";
        if (empty($domicilio)) {
            $error = "El campo de domicilio es necesario";
        }
        return $error;
    }

    private static function validarDNI($DNI) {
        $error = "";
        $DNIPattern = '/^[0-9]{8}[A-Z]{1}$/';
        if (empty($DNI)) {
            $error = "El campo de DNI es necesario";
        } else if (!preg_match($DNIPattern, $DNI)) {
            $error = "DNI no válido. El formato es: 12345678A";
        }
        return $error;
    }

    private static function validarTelefono($tel) {
        $error = "";
        if (empty($tel)) {
            $error = "El campo de teléfono es necesario";
        } else if (!preg_match("/^\d{9}$/", $tel)) {
            $error = "El teléfono debe tener 9 dígitos. El formato es: 555555555";
        }
        return $error;
    }

    private static function validarEmail($email) {
        $error = "";
        $emailPattern = '/^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/';
        if (empty($email)) {
            $error = "Este campo es necesario";
        } else if (!preg_match($emailPattern, $email)) {
            $error = "Email no válido. El formato es: example@gmail.com";
        }
        return $error;
    }

    private static function validarCIF($CIF) {
        $error = "";
        $CIFPattern = '/^[A-Z]{1}[0-9]{7}[A-Z]{1}$/';
        if (empty($CIF)) {
            $error = "Este campo es necesario";
        } else if (!preg_match($CIFPattern, $CIF)) {
            $error = "CIF no válido";
        }
        return $error;
    }

    private static function validarNIFGerente($NIFGerente) {
        $error = "";
        $NIFPattern = '/^[0-9]{8}[A-Z]{1}$/';
        if (empty($NIFGerente)) {
            $error = "Este campo es necesario";
        } else if (!preg_match($NIFPattern, $NIFGerente)) {
            $error = "NIF del gerente no válido";
        }
        return $error;
    }
}
?>