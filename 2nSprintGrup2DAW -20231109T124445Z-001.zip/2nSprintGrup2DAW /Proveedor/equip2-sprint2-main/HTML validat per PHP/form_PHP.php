<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
require 'src/Proveedor.php';
require 'lib/Validator.php';
require 'src/DB.php';
session_start();



try {
    $db = new Database("mysql-server", "db_proyecto", "root", "secret");
} catch (Exception $exception) {
    die("Error de conexión a la base de datos: " . $exception->getMessage());
}function generarTokenCSRF() {
    if (!isset($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

$errores = [];

if ($_SERVER["REQUEST_METHOD"] === "POST" &&
    isset($_POST['csrf_token']) && 
    $_POST['csrf_token'] === $_SESSION ['csrf_token']) {

    $nombre = $_POST["nombre"];
    $domicilio = $_POST["domicilio"];
    $DNI = $_POST["DNI"];
    $tel = $_POST["tel"];
    $email = $_POST["email"];
    $CIF = $_POST["CIF"];
    $NIFGerente = $_POST["NIF_gerente"];

    // Validar los campos utilizando la clase Validator
    $campos = [
        'nombre' => $nombre,
        'domicilio' => $domicilio,
        'DNI' => $DNI,
        'tel' => $tel,
        'email' => $email,
        'CIF' => $CIF,
        'NIF_gerente' => $NIFGerente
    ];

    $errores = Validator::validateFields($campos);

    if (empty(array_filter($errores))) {
        try {
            if ($db->insertProveedor($nombre, $domicilio, $DNI, $tel, $email, $CIF, $NIFGerente)) {
                echo "Datos del proveedor insertados correctamente en la base de datos.";
            } else {
                echo "Error al insertar los datos del proveedor.";
            }
        } catch (Exception $exception) {
            echo "Error al insertar los datos del proveedor: " . $exception->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulario de Proveedor</title>
</head>
<body>
    <h1>Datos de Proveedor</h1>
    <?php
    foreach ($errores as $error) {
        echo "<p>$error</p>";
    }
    ?>
    <form action="form_PHP.php" method="post">
    <label for="nombre">Nombre:</label>
        <input type="text" id="nombre" name="nombre"  value="<?php echo isset($Data) ? htmlspecialchars($Data->getNombre()) : 'El nombre ingresado no es correcto'; ?>"><br>
        
        <label for="domicilio">Domicilio:</label>
        <input type="text" id="domicilio" name="domicilio" value="<?php echo isset($Data) ? htmlspecialchars($Data->getDomicilio()) : 'El domicilio ingresado no es correcto'; ?>"><br>
        
        <label for="DNI">DNI:</label>
        <input type="text" id="DNI" name="DNI" value="<?php echo isset($Data) ? htmlspecialchars($Data->getDNI()) : 'El DNI ingresado no es correcto'; ?>"><br>
        
        <label for="tel">Teléfono:</label>
        <input type="tel" id="tel" name="tel" value="<?php echo isset($Data) ? htmlspecialchars($Data->getTelefono()) : 'El teléfono
         ingresado no es correcto'; ?>"><br>
        
        <label for="email">Email:</label>
        <input type="email" id="email" name="email" value="<?php echo isset($Data) ? htmlspecialchars($Data->getEMail()) : 'NO'; ?>"><br>
        
        <label for="CIF">CIF:</label>
        <input type="text" id="CIF" name="CIF" value="<?php echo isset($Data) ? htmlspecialchars($Data->getCIF()) : 'NO'; ?>"><br>
        
        <label for="NIF_gerente">NIF del Gerente:</label>
        <input type="text" id="NIF_gerente" name="NIF_gerente" value="<?php echo isset($Data) ? htmlspecialchars($Data->getNifGerente()) : 'NO'; ?>"><br>
        
        <input type="hidden" name="csrf_token" value="<?php echo generarTokenCSRF(); ?>">
    </form>
</body>
</html>
