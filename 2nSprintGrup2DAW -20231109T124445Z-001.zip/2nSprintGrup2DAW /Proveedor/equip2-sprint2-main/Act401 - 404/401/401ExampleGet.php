<!DOCTYPE html>
<html>
<head>
    <title>Benvingut Pàgina</title>
</head>
<body>
    <h1>Benvingut <?php echo($_GET['nom']) ?>!!!</h1>
</body>
</html>
